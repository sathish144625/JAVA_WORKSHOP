package com.arjuncodes.springemaildemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEmailDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
